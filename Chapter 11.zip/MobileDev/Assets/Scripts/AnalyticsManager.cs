using System.Collections.Generic; /* List */
using Unity.Services.Analytics; /* AnalyticsService, ConsentCheckException */
using Unity.Services.Core; /* UnityServices */
using UnityEngine;

public class AnalyticsManager : MonoBehaviour
{
    // Start is called before the first frame update
    async void Start()
    {
        try
        {
            await UnityServices.InitializeAsync();
            List<string> consentIdentifiers = await AnalyticsService.Instance.CheckForRequiredConsents();
        }
        catch (ConsentCheckException)
        {
            /* Something went wrong */
        }
    }

}
