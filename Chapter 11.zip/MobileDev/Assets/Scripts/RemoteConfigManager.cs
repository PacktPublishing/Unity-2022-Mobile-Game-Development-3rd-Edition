using UnityEngine;
using Unity.RemoteConfig; /* ConfigManager */

public class RemoteConfigManager : MonoBehaviour
{
    public PlayerBehaviour playerBehaviour;

    public struct userAttributes { }

    public struct appAttributes { }

    private void Awake()
    {
        ConfigManager.FetchCompleted += ApplyRemoteSettings;
        ConfigManager.FetchConfigs<userAttributes, appAttributes>(new userAttributes(), new appAttributes());
    }

    private void ApplyRemoteSettings(ConfigResponse configResponse)
    {
        /* Check if new settings that have been loaded */
        if (configResponse.requestOrigin == ConfigOrigin.Remote)
        {
            /* There are, so values should be updated */
            playerBehaviour.UpdateRemoteConfigValues();
        }
    }
}
